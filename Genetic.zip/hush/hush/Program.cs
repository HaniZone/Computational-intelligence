﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;

/*in the name of God 
 * 
 * Mohammad Ostadi
 * Mohammad Farhoudikia
 * 
 * You can resize the population size and cromozom size in ga class
 * by changing Psize , PLindex , CSize and CLindex
 * 
 * You can change configs inside ga
 * 
 * You can change obstacles map inside ga by changing map array and set obstacle lines in 
 * OBS array too
 * 
 * 
 * 
 * 
 
 */

namespace C_ga1
{
    class node
    {
        public int x;
        public int y;
        public node(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public node() { }
        public static Boolean operator ==(node a, node b)
        {
            if (a.x == b.x && a.y == b.y)
                return true;
            else
                return false;
        }
        public static Boolean operator !=(node a, node b)
        {
            if (a.x == b.x && a.y == b.y)
                return false;
            else
                return true;
        }

    }
    class Cromozom : ICloneable
    {
        public node[] Kr = new node[ga.CSize];
        public double F = 0; //fitness
        public double L = 0; // path length
        private double a = 1000; //zaribe length
        public int T = 0; //number of obstacle intersection
        private double b = -1; //zaribe intersection



        public Cromozom()
        {


            Kr[0] = new node(ga.startx, ga.starty);
            Kr[ga.CLindex] = new node(ga.finalx, ga.finaly);
            int X, Y;
            for (int i = 1; i < ga.CLindex; i++)
            {
                Kr[i] = new node();
                ga.getNewXY(out X, out Y);
                Kr[i].x = X;
                Kr[i].y = Y;
            }

        }
        public object this[int index]
        {
            get { return Kr[index]; }
            set { /* set the specified index to value here */ }
        }

        private double pathLength(node a, node b)
        {
            return (Math.Sqrt(Math.Pow(b.x - a.x, 2) + Math.Pow(b.y - a.y, 2)));
        }
        /// <summary>
        /// check path intercetion with obstacles
        /// </summary>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <param name="OBS"></param>
        /// <returns></returns>
        private bool CheckIntercetion(node A, node B, node[,] OBS)
        {
            for (int i = 0; i < OBS.GetLength(1); i++)
            {
                if (LinesIntersect(A, B, OBS[0, i], OBS[1, i]))
                    return true;
            }
            return false;
        }

        static bool LinesIntersect(node A, node B, node C, node D)
        {
            node CmP = new node(C.x - A.x, C.y - A.y);
            node r = new node(B.x - A.x, B.y - A.y);
            node s = new node(D.x - C.x, D.y - C.y);

            float CmPxr = CmP.x * r.y - CmP.y * r.x;
            float CmPxs = CmP.x * s.y - CmP.y * s.x;
            float rxs = r.x * s.y - r.y * s.x;

            if (CmPxr == 0f)
            {
                // Lines are collinear, and so intersect if they have any overlap

                return ((C.x - A.x < 0f) != (C.x - B.x < 0f))
                    || ((C.y - A.y < 0f) != (C.y - B.y < 0f));
            }

            if (rxs == 0f)
                return false; // Lines are parallel.

            float rxsr = 1f / rxs;
            float t = CmPxs * rxsr;
            float u = CmPxr * rxsr;

            return (t >= 0f) && (t <= 1f) && (u >= 0f) && (u <= 1f);
        }

        public double FitnessCalc()
        {
            L = 0;
            T = 0;
                for (int i = 0; i < ga.CLindex; i++)
                {
                    L += pathLength(Kr[i], Kr[i + 1]);
                    if (CheckIntercetion(Kr[i], Kr[i + 1], ga.OBS))
                        T++;
                }
                F = Math.Round(a / L + b * T, 3);
                // Console.WriteLine(T +"  "+ F);
                //F = ( a / L + b * T);
                return F;
            
    }

        public object Clone()
        {
            return this.MemberwiseClone();
            // throw new NotImplementedException();
        }
    }
    class ga
    {
        //play options
        public static bool FancyDisplay = true; // show both result : best and current
        public static bool WaitForKey = true;
        public static bool ClearOnEnd = true;
        public static bool NotIntersect = true;


        #region a
        //genetic configs
        public static Random r = new Random();
        public static int PSize = 100, CSize = 25; //population and Cromozom size
        public static int PLindex = 99, CLindex = 24; //population and Cromozom array last index
        public static int startx = 13, starty = 0, finalx = 0, finaly = 9;
        // x is row and y is column
        public static int[,] map =
        {
            {0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {2,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},

        };
        //obstacle lines
        public static node[,] OBS =
        {
            {new node(2,3),new node(2,3),new node(2,7),new node(8,7),new node(8,11),new node(8,11),new node(14,11),new node(8,14) },
            {new node(8,3),new node(2,7),new node(8,7),new node(8,3),new node(8,14),new node(14,11),new node(14,14),new node(14,14) }
        };

        //functions
        public static bool isObstacle(node a)
        {
            if (map[a.x, a.y] == 1)
                return true;
            return false;
        }
        public static bool isObstacle(int x, int y)
        {

            if (ga.NotIntersect && map[x, y] == 1)
                return true;
            return false;
        }
        public static void BubbleSort(Cromozom[] p)
        {
            bool swapped;
            // Cromozom temp = new Cromozom();
            Cromozom temp;
            for (int i = 0; i < p.Length - 1; i++)
            {
                swapped = false;
                for (int j = 0; j < p.Length - i - 1; j++)
                {
                    if (p[j].F < p[j + 1].F)
                    {
                        temp = p[j];
                        p[j] = p[j + 1];
                        p[j + 1] = temp;
                        swapped = true;
                    }
                }
                if (swapped == false)
                    break;
            }
        }
        private int getNewX(int y)
        {
            Random r = new Random(GetHashCode() * DateTime.Now.Millisecond);
            int newx = r.Next(0, 16);
            while (isObstacle(newx, y))
            {
                newx = r.Next(0, 16);
            }
            return newx;
        }
        private int getNewY(int x)
        {
            Random r = new Random(GetHashCode() * DateTime.Now.Millisecond);
            int newy = r.Next(0, 16);

            while (isObstacle(x, newy))
            {
                newy = r.Next(0, 16);
            }
            return newy;
        }
        public static void getNewXY(out int x, out int y)
        {
            x = 1;
            // Random r = new Random(x.GetHashCode() * DateTime.Now.Millisecond);
            int newy = r.Next(0, 16);
            int newx = r.Next(0, 16);
            while (isObstacle(newx, newy))
            {
                newx = r.Next(0, 16);
                newy = r.Next(0, 16);
            }
            x = newx;
            y = newy;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="p">population</param>
        public void CrossOver(Cromozom[] p)
        {
            Random r = new Random(GetHashCode());
            int pc; //crossover point
            int pclow = Convert.ToInt32(CSize * 0.6);
            int pchigh = Convert.ToInt32(CSize * 0.9);

            int ph = PSize / 2;
            int child1, child2; //new childrens index

            for (int i = 0; i < ph; i += 2)
            {
                pc = r.Next(pclow, pchigh);

                child1 = i + ph;
                child2 = i + ph + 1;

                p[child1] = new Cromozom();
                p[child2] = new Cromozom();

                for (int j = 0; j < CSize; j++)
                {
                    if (j < pc)
                    {
                        p[child1][j] = p[i][j];
                        p[child2][j] = p[i + 1][j];
                    }
                    else
                    {
                        p[child1][j] = p[i + 1][j];
                        p[child2][j] = p[i][j];
                    }

                }

            }
        }
        #endregion a
        public void Mutate(Cromozom[] p)
        {

            int pm; //mutation rate
            int pmlow = Convert.ToInt32((1.0 / PSize) * 100);
            int pmhigh = Convert.ToInt32((1.0 / CSize) * 100);

            int m_point; //mutation point
            int x, y;
            for (int i = 0; i < PSize; i++)
            {


                if (headOrTail())//headOrTail()
                {
                    pm = r.Next(0, pmhigh);

                    while (pm > 0)
                    {


                        m_point = r.Next(1, ga.CLindex - 1);
                        if (headOrTail())
                        {
                            p[i].Kr[m_point].x = getNewX(p[i].Kr[m_point].y);
                        }
                        else
                        {

                            p[i].Kr[m_point].y = getNewY(p[i].Kr[m_point].x);
                        }

                        //getNewXY(out x, out y);
                        //p[i].Kr[m_point] = new node(x, y);

                        pm--;
                    }

                }



            }
        }
        private bool headOrTail()
        {
            //Random r = new Random(GetHashCode() * DateTime.Now.Millisecond);

            int t = r.Next(0, 1000);



            if (t > 500)
            {
                //  Console.WriteLine("head");
                return true;
            }
            //Console.WriteLine("tail");
            return false;
        }
    }
    class Program
    {
        static void FancyDisplay(string[,] dotmap, string title)
        {

            Console.WriteLine();
            Console.Write("           " + "+");
            for (int j = 0; j < 16; j++)
            {
                Console.Write("--+");
            }
            Console.WriteLine();
            for (int i = 0; i < 16; i++)
            {
                Console.Write("           " + "|");
                for (int j = 0; j < 16; j++)
                {
                    Console.Write(dotmap[i, j] + "|");
                }
                Console.WriteLine();
                Console.Write("           " + "+");
                for (int j = 0; j < 16; j++)
                {
                    Console.Write("--+");
                }
                Console.WriteLine();
            }
        }
        static void DoubleFancyDisplay(int generation, double last_improve, string[,] dotmap1, string title1, double F1, int T1, double L1, string[,] dotmap2, string title2, double F2, int T2, double L2)
        {
            last_improve = Math.Round(last_improve, 2);
            L1 = Math.Round(L1, 2);
            L2 = Math.Round(L2, 2);
            double F1percent = Math.Round(F1 * 100 / 63, 2);
            double F2percent = Math.Round(F2 * 100 / 63, 2);

            Console.WriteLine("Generation = " + generation + " End!" + "Fitness = " + F2 + " improvement = " + last_improve);
            // Console.WriteLine("Intersection = " + T1 + "  " + "  Length = " + L2);

            Console.WriteLine();
            Console.WriteLine();
            Console.Write("           " + title1 + "                                            " + title2);
            Console.WriteLine();
            Console.Write("   Fitness = " + F1percent + "%   Intersection = " + T1 + "  Length = " + L1 + "     Fitness = " + F2percent + "%  Intersection = " + T2 + "  " + "  Length = " + L2);
            Console.WriteLine();
            Console.Write("   +");
            for (int j = 0; j < 16; j++)
            {
                Console.Write("--+");
            }
            Console.Write("       +");
            for (int j = 0; j < 16; j++)
            {
                Console.Write("--+");
            }
            Console.WriteLine();


            for (int i = 0; i < 16; i++)
            {
                Console.Write("   |");
                for (int j = 0; j < 16; j++)
                {
                    Console.Write(dotmap1[i, j] + "|");

                }
                Console.Write("       |");  // space in middle
                for (int j = 0; j < 16; j++)
                {
                    Console.Write(dotmap2[i, j] + "|");

                }

                Console.WriteLine();
                Console.Write("   +");
                for (int j = 0; j < 16; j++)
                {
                    Console.Write("--+");
                }
                Console.Write("       +");
                for (int j = 0; j < 16; j++)
                {
                    Console.Write("--+");
                }
                Console.WriteLine();
            }
        }


        static void Main(string[] args)
        {


            ga Ga = new ga();
            Cromozom[] p = new Cromozom[ga.PSize];
            for (int i = 0; i < p.Length; i++)
            {
                p[i] = new Cromozom();

            }
            Cromozom MostFittest = new Cromozom();
            MostFittest.FitnessCalc();

            /*
            Cromozom BestFittest = new Cromozom();
            int[] bestx = { 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 };
            int[] besty = { 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9};

            for (int i = 1; i < ga.CLindex; i++)
            {
                BestFittest.Kr[i].x = bestx[i-1];
                BestFittest.Kr[i].y = besty[i-1];
            }
            BestFittest.FitnessCalc();
            */

            double last_improve = 0, last_fittest = 0;
            int generation = 1;
            do
            {

                if (generation > 1)
                {
                    for (int i = 50; i < p.Length; i += 2)
                    {
                        p[i] = new Cromozom();
                    }
                    Ga.CrossOver(p);
                    Ga.Mutate(p);

                }



                for (int i = 0; i < p.Length; i++)
                {

                    p[i].FitnessCalc();
                    // Console.WriteLine(p[i].F);
                }
                ga.BubbleSort(p);
                string[,] dotmapBest, dotmapCurrent = new string[16, 16];


                for (int i = 0; i < 16; i++)
                    for (int j = 0; j < 16; j++)
                    {
                        if (ga.map[i, j] == 1)
                            dotmapCurrent[i, j] = "* ";
                        else
                            dotmapCurrent[i, j] = "  ";
                    }


                dotmapBest = (string[,])dotmapCurrent.Clone();
                for (int i = 0; i < ga.CSize; i++)
                {
                    if (i < 10)
                        dotmapCurrent[p[0].Kr[i].x, p[0].Kr[i].y] = " " + i.ToString();
                    else
                        dotmapCurrent[p[0].Kr[i].x, p[0].Kr[i].y] = i.ToString();

                }


                last_improve = p[0].F - last_fittest;
                last_fittest = p[0].F;


                //max
                if (p[0].F > MostFittest.F)
                    MostFittest = (Cromozom)p[0].Clone();


                for (int i = 0; i < ga.CSize; i++)
                {
                    if (i < 10)
                        dotmapBest[MostFittest.Kr[i].x, MostFittest.Kr[i].y] = " " + i.ToString();
                    else
                        dotmapBest[MostFittest.Kr[i].x, MostFittest.Kr[i].y] = i.ToString();

                }






                if (ga.FancyDisplay)
                {
                    DoubleFancyDisplay(generation, last_improve, dotmapBest, "Fittest of all time", MostFittest.F, MostFittest.T, MostFittest.L, dotmapCurrent, "Fittest of this gen", p[0].F, p[0].T, p[0].L);
                }
                else
                {

                    //if (generation % 1000 == 0)
                    {
                        Console.WriteLine("Generation = " + generation + " End!" + "Fitness = " + p[0].F + " improvement = " + last_improve);
                        Console.WriteLine("Intersection = " + p[0].T + "  " + "  Length = " + p[0].L);

                        Console.WriteLine("Best Fitness of all generations = " + MostFittest.F);

                        Console.WriteLine();
                        Console.WriteLine();

                        for (int i = 0; i < 16; i++)
                        {
                            Console.Write("           " + "|");
                            for (int j = 0; j < 16; j++)
                            {
                                Console.Write(dotmapCurrent[i, j] + "|");
                            }
                            Console.WriteLine();

                        }
                    }
                }

                //generation%1000==0 &&
                if (ga.WaitForKey)
                {
                    Console.WriteLine("press any key to continue...");
                    Console.ReadKey();
                }
                if (ga.ClearOnEnd)
                    Console.Clear();
                generation++;




            } while (true);




        }

    }
}
